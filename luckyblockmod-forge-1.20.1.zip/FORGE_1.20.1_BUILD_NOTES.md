# Forge 1.20.1 build package

- Minecraft target: 1.20.1
- Forge target: 47.3.0
- Java toolchain: 17
- Gradle workflow: 8.8
- Abilities: 34, plus passive double-speed flight
- Includes the tesseract VFX overhaul and ability clutter limits from the current Forge source.

This package is source code plus a GitHub Actions build workflow. It is not a precompiled JAR. The source archive and workflow have been statically checked, but a full Forge build still needs to run in GitHub Actions because this environment cannot resolve the Gradle distribution host.
