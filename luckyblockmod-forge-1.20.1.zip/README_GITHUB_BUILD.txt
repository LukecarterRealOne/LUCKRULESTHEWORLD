Lucky Block Ascension — Forge 1.20.1

Upload this source project to a GitHub repository, or put the source archive named luckyblockmod-forge-1.20.1.zip in the repository root alongside .github/workflows/build.yml. The workflow uses Java 17 and Gradle 8.8, extracts the ZIP when needed, verifies it is the Forge 1.20.1 project (not NeoForge), runs clean build, and uploads the JAR as the luckyblockmod-forge-1.20.1 artifact.

The archive contains source code, not a precompiled JAR. GitHub Actions must finish successfully before installing the JAR.
