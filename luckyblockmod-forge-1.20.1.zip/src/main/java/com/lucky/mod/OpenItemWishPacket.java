package com.lucky.mod;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: open the searchable item catalogue for Item Wish. */
public class OpenItemWishPacket {
    public static void encode(OpenItemWishPacket message, net.minecraft.network.FriendlyByteBuf buffer) {}

    public static OpenItemWishPacket decode(net.minecraft.network.FriendlyByteBuf buffer) {
        return new OpenItemWishPacket();
    }

    public static void handle(OpenItemWishPacket message, Supplier<NetworkEvent.Context> context) {
        context.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> ClientItemWish::open));
        context.get().setPacketHandled(true);
    }
}
