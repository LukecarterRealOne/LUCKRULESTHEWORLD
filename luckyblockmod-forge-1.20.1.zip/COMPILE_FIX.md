# Compile fix

The tesseract overhaul's `Fx.java` referenced `ParticleTypes.EXPLOSION_EMITTER`, `ParticleTypes.FLASH`, and `ParticleTypes.SONIC_BOOM` without importing `net.minecraft.core.particles.ParticleTypes`. The missing import has been added. If GitHub Actions still fails, inspect the first compiler diagnostics above `Execution failed for task ':compileJava'` and address those separately.
